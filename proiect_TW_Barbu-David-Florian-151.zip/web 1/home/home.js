window.onload = function () {
    var mute = true
    var hasPlayed = false
    document.querySelector("audio").pause()
    document.querySelector("#sound-icon").addEventListener("click", (e) => {
        if ( hasPlayed == false && mute == true ){
            document.querySelector("audio").play()
            e.target.src = "../resources/volume.png"
            hasPlayed = true
            mute = false
        }
        else
        if ( mute == true ){
            document.querySelector("audio").muted = false
            e.target.src = "../resources/volume.png"
            mute = false
        }
        else
        if ( hasPlayed == true && mute == false ){
            document.querySelector("audio").muted = true
            e.target.src = "../resources/mute.png"
            mute = true
        }
    })
}