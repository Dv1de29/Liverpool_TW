export async function read(path, file="txt"){
    try{
        const response = await fetch(path);
        console.log("Fetching: ", path);

        if ( !response.ok ){
            throw new Error('Network response was not ok');
        }
        let data
        if ( file === "txt" ){
            data = await response.text();
        }
        else
            if ( file === "json" ){
                data = await response.json();
            }
        
        return data;    
    } catch (error){
        console.error('There was an error retrieving the data:', error);
        return null;
    }
}