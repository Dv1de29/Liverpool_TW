import { read } from '../helper.js'

let global_match

let start_lineup = [0,1,3,2,4,17,5,6,8,9,10]
let gk = [0,22,21]
let def = [1,2,3,4,11,12,19,20]
let mid = [5,6,7,13,16,17,1]
let att = [8,9,10,14,15,18,13]
const mapPos = {
    gk: gk,
    def: def,
    mid: mid,
    att: att,
}
let ap = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
let data;

const body = document.querySelector("body");
body.style.width = window.innerWidth;

function add_players(){
    const temp = document.querySelector("#player-show");
    const container = document.querySelector(".player-prev");
    for ( let i = 0; i < 11; i++ ){
        const tem = temp.content.cloneNode(true);
        let name = tem.querySelector("#name");
        let surname = tem.querySelector("#surname");
        let position = tem.querySelector("#position");
        let country = tem.querySelector(".country-box img");
        let shnumb = tem.querySelector(".card-number span");
        let plimg = tem.querySelector(".img-box img");
        name.textContent = data.squad[start_lineup[i]].name;
        surname.textContent = data.squad[start_lineup[i]].surname;
        position.textContent = data.squad[start_lineup[i]].position;
        country.src = `../resources/countries/${data.squad[start_lineup[i]].country}.png`;
        shnumb.textContent = data.squad[start_lineup[i]].shirt_number;
        try{
            plimg.src = `../resources/players/${data.squad[start_lineup[i]].name}.webp`;   
            }
            catch (error){
                console.log(`../resources/players/${data.squad[start_lineup[i]].name}.webp`);
            } 
        container.appendChild(tem);
    }

    let plbox = document.querySelectorAll("#players-cont > div > div");
    for ( let i = 0; i < 11; i++ ){
        try{
        plbox[i].querySelector(".imageslot img").src = `../resources/players/${data.squad[start_lineup[i]].name}.webp`;   
        }
        catch (error){
            console.log("Squad builder error: ", `../resources/players/${data.squad[start_lineup[i]].name}.webp`);
        } 
        plbox[i].querySelector(".player-info #name").textContent = data.squad[start_lineup[i]].surname;
        plbox[i].querySelector(".player-info #number").textContent = data.squad[start_lineup[i]].shirt_number;
        plbox[i].querySelector(".player-info .country img").src = `../resources/countries/${data.squad[start_lineup[i]].country}.png`;
        plbox[i].querySelector(".player-info .count").textContent = data.squad[start_lineup[i]].count;
        ap[i] = 1;
    }
}

window.stli_reset = function (){
    let plbox = document.querySelectorAll("#players-cont > div > div");
    for ( let i = 0; i < 11; i++ ){
        try{
        plbox[i].querySelector(".imageslot img").src = `../resources/players/${data.squad[start_lineup[i]].name}.webp`;   
        }
        catch (error){
            console.log("Squad builder error: ", `../resources/players/${data.squad[start_lineup[i]].name}.webp`);
        } 
        plbox[i].querySelector(".player-info #name").textContent = data.squad[start_lineup[i]].surname;
        plbox[i].querySelector(".player-info #number").textContent = data.squad[start_lineup[i]].shirt_number;
        plbox[i].querySelector(".player-info .country img").src = `../resources/countries/${data.squad[start_lineup[i]].country}.png`;
        plbox[i].querySelector(".player-info .count").textContent = data.squad[start_lineup[i]].count;
        ap[i] = 1;
    }
}

window.changeleft = function (e,position){
    let imgslot = e.parentElement; 
    let plinfo = imgslot.parentElement.querySelector(".player-info");
    let index = parseInt(plinfo.querySelector(".count").textContent,10);
    let last = index;
    while( ap[index] ){
        if ( index == mapPos[position]?.[0] ){
            index = mapPos[position]?.[mapPos[position]?.length-1]
        }else
        index = mapPos[position]?.[mapPos[position]?.indexOf(index)-1]
    }
    ap[last] = 0;
    ap[index] = 1;

    try{
        imgslot.children[0].src = `../resources/players/${data.squad[index].name}.webp`;
    }
    catch{
        console.log("Squad builder error:", `../resources/players/${data.squad[index].name}.webp`);
    }

    plinfo.querySelector("#name").textContent = data.squad[index].surname;
    plinfo.querySelector("#number").textContent = data.squad[index].shirt_number
    plinfo.querySelector(".country img").src = `../resources/countries/${data.squad[index].country}.png`;
    plinfo.querySelector(".count").textContent = data.squad[index].count
}

window.changeright = function(e,position){
    let imgslot = e.parentElement; 
    let plinfo = imgslot.parentElement.querySelector(".player-info");
    let index = parseInt(plinfo.querySelector(".count").textContent,10);
    let last = index;
    while( ap[index] ){
        index = mapPos[position]?.[(mapPos[position]?.indexOf(index)+1)%(mapPos[position]?.length)]
    }
    ap[last] = 0;
    ap[index] = 1;

    try{
        imgslot.children[0].src = `../resources/players/${data.squad[index].name}.webp`;
    }
    catch{
        console.log(`../resources/players/${data.squad[index].name}.webp`);
    }
    plinfo.querySelector("#name").textContent = data.squad[index].surname;
    plinfo.querySelector("#number").textContent = data.squad[index].shirt_number
    plinfo.querySelector(".country img").src = `../resources/countries/${data.squad[index].country}.png`;
    plinfo.querySelector(".count").textContent = data.squad[index].count
}

let hasPlayed = false;
window.permitsong = function (){

    const audio = document.querySelector('.YNWA audio');
    if ( !hasPlayed ){
        audio.play();
        hasPlayed = true;
    }
}


function calculateTimeDifference(startDate, endDate) {

    const differenceInMilliseconds = endDate - startDate;

    const days = Math.floor(differenceInMilliseconds / (1000 * 60 * 60 * 24));
    const hours = Math.floor((differenceInMilliseconds % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((differenceInMilliseconds % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((differenceInMilliseconds % (1000 * 60)) / 1000);

    let time = document.querySelector("#match-cont .timer span")
    time.textContent = `${days} day(s) ${hours} hours ${minutes} minutes ${seconds} seconds`
}

window.onload = function (){
    var date = new Date("2025-01-18T17:00:00")
    setInterval(() => {
        calculateTimeDifference(new Date(), date)
    }, 1000)

    var cond = localStorage.getItem("match")
    console.log(cond)
    if ( cond !== null ){
        adding_players_score(cond)
    }
}

var matches = [
    [0,1,20,2,4,17,5,6,8,15,10,"ips","0-2", "liv"],
    [0,1,2,3,4,17,5,6,8,15,10,"liv","2-0", "bre"],
    [0,1,2,3,4,17,5,6,8,15,10,"man","0-3", "liv"],
    [0,1,2,3,4,17,5,6,8,15,10,"liv","0-1", "ntf"],
    [22,1,2,3,4,17,5,6,8,9,10,"liv","3-0", "bour"],
    [0,1,2,3,4,17,5,6,8,15,10,"wol","1-2", "liv"],
    [0,1,2,3,12,17,5,7,8,9,10,"cry","0-1", "liv"],
    [22,1,2,3,4,17,7,6,8,15,14,"liv","2-1", "che"],
    [22,1,2,3,4,17,7,5,8,9,10,"ars","2-2", "liv"],
    [22,1,2,3,12,17,5,6,8,9,14,"liv","1-0", "bri"],
    [22,1,2,3,4,17,7,5,8,9,10,"liv","2-0", "astvilla"],
    [22,19,2,3,4,17,6,7,8,9,14,"sou","2-3", "liv"],
    [22,1,2,11,4,17,6,5,8,14,10,"liv","2-0", "city"],
    [22,20,2,11,4,17,7,5,8,9,14,"new","3-3", "liv"],
    [0,1,2,11,4,17,7,6,8,14,10,"liv","2-2", "ful"],
    [0,1,2,11,4,5,6,17,8,14,10,"tot","3-6", "liv"],
    [0,1,2,11,4,17,7,17,8,9,14,"liv","3-1", "lei"],
    [0,1,2,11,4,17,7,5,8,14,10,"wham","0-5", "liv"],
]

document.querySelector(".btn-match-select").addEventListener("click", () => {
    let select = document.querySelector("#match-select").value

    let plbox = document.querySelectorAll("#players-cont > div > div");
    for ( let i = 0; i < 11; i++ ){
        var mitumiau = matches[select-1][i]
        console.log(mitumiau)
        try{
        plbox[i].querySelector(".imageslot img").src = `../resources/players/${data.squad[mitumiau].name}.webp`;   
        }
        catch (error){
            console.log("Squad builder error: ", `../resources/players/${data.squad[mitumiau].name}.webp`);
        } 
        plbox[i].querySelector(".player-info #name").textContent = data.squad[mitumiau].surname;
        plbox[i].querySelector(".player-info #number").textContent = data.squad[mitumiau].shirt_number;
        plbox[i].querySelector(".player-info .country img").src = `../resources/countries/${data.squad[mitumiau].country}.png`;
        plbox[i].querySelector(".player-info .count").textContent = data.squad[mitumiau].count;
        ap[i] = 1;
    }

    let teams = document.querySelectorAll(".match-select-score .teams img")
    console.log(teams)
    teams[0].src = `../resources/${matches[select-1][11]}-simple.png`
    teams[1].src = `../resources/${matches[select-1][13]}-simple.png`
    document.querySelector(".match-select-score span").textContent = matches[select-1][12]

    document.querySelector(".match-select-score").style.backgroundColor = "grey"

    localStorage.setItem('match', select)
})

function adding_players_score(select){
        let plbox = document.querySelectorAll("#players-cont > div > div");
        for ( let i = 0; i < 11; i++ ){
            var mitumiau = matches[select-1][i]
            console.log(mitumiau)
            try{
            plbox[i].querySelector(".imageslot img").src = `../resources/players/${data.squad[mitumiau].name}.webp`;   
            }
            catch (error){
                console.log("Squad builder error: ", `../resources/players/${data.squad[mitumiau].name}.webp`);
            } 
            plbox[i].querySelector(".player-info #name").textContent = data.squad[mitumiau].surname;
            plbox[i].querySelector(".player-info #number").textContent = data.squad[mitumiau].shirt_number;
            plbox[i].querySelector(".player-info .country img").src = `../resources/countries/${data.squad[mitumiau].country}.png`;
            plbox[i].querySelector(".player-info .count").textContent = data.squad[mitumiau].count;
            ap[i] = 1;
        }
    
        let teams = document.querySelectorAll(".match-select-score .teams img")
        console.log(teams)
        teams[0].src = `../resources/${matches[select-1][11]}-simple.png`
        teams[1].src = `../resources/${matches[select-1][13]}-simple.png`
        document.querySelector(".match-select-score span").textContent = matches[select-1][12]
    
        document.querySelector(".match-select-score").style.backgroundColor = "grey"
}

document.addEventListener("DOMContentLoaded", async () => {
    data = await read('../resources/players.json', "json");
    add_players();
    var cond = localStorage.getItem("match")
    if ( cond !== null ){
        adding_players_score(cond)
    }

    // const container = document.querySelector('#stadium-cont .title');
    // const audio = document.querySelector('.YNWA audio');

    // let hasPlayed = false; // Track if the audio has been triggered

    // const observer = new IntersectionObserver((entries) => {
    //     entries.forEach(entry => {
    //         if (entry.isIntersecting && !hasPlayed && permission) {
    //                 audio.play();
    //                 hasPlayed = true; // Ensure it only plays once
    //         }
    //     });
    // });

    // observer.observe(container);
});
