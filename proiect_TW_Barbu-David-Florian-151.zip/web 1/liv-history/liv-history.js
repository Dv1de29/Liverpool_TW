import { read } from '../helper.js';

const body = document.querySelector("body");
body.style.width = window.innerWidth;

function add_section(n,data){
    const section_box = document.querySelector(".content_box");
    const content_box = document.querySelector("#content");
    for( let i = 1; i < n; ++i )
    {   if( data[i] ){   
        const temp = section_box.content.cloneNode(true);
        let title = temp.querySelector("#title");
        title.textContent = data[i++];
        let txt = temp.querySelector("#text");
        txt.textContent = data[i++];
        let img = temp.querySelector(".section img");
        img.src = data[i++];
        let mtext = temp.querySelector(".cont-temp .maintext p");
        mtext.textContent = data[i];
        let element = temp.children[0];
        const eheight = element.style.height;
        element.addEventListener("click", function(){

            element.style.height = element.style.height === 'fit-content' ? eheight : 'fit-content';
        });
        content_box.appendChild(temp);
        }
    }
}

document.addEventListener("DOMContentLoaded", async () => {
    const path = '../resources/liv-history.txt';
    let data = await read(path);
    if ( data ){
        data = data.split('\n');
        data = data.filter((data) => data.trim() != "")
        // for ( let i = 0; i < data.length; i++)
        // {
        //     console.log(data[i]);
        // }
        add_section(data.length,data); 
    }
});


